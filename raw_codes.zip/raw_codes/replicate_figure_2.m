addpath(genpath(cd));

figure;
beta2star_rho;

figure;
varratio;
