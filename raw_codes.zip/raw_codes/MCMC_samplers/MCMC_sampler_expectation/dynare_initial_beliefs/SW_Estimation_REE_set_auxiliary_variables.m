function y = SW_Estimation_REE_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(28)=x(6);
y(29)=x(7);
