clear;
clc;

addpath(genpath(cd));
blew;